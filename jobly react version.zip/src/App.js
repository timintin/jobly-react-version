
import React, { useState, useEffect } from 'react';
import { BrowserRouter, Route, Switch, Redirect } from 'react-router-dom';
import jwt_decode from 'jwt-decode';
import JoblyApi from './api';
import HomePage from './components/HomePage';
import CompanyList from './components/CompanyList';
import CompanyDetail from './components/CompanyDetail';
import JobList from './components/JobList';
import Login from './components/Login';
import Signup from './components/Signup';
import Profile from './components/Profile';
import UserContext from './components/UserContext';
import useLocalStorage from './components/useLocalStorage';

function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [token, setToken] = useLocalStorage('jobly-token');

  // Function to handle login
  const login = async (loginData) => {
    try {
      const token = await JoblyApi.login(loginData);
      setToken(token);
    } catch (err) {
      console.error("Login failed", err);
    }
  };

  // Function to handle signup
  const signup = async (signupData) => {
    try {
      const token = await JoblyApi.signup(signupData);
      setToken(token);
    } catch (err) {
      console.error("Signup failed", err);
    }
  };

  // Function to handle logout
  const logout = () => {
    setToken(null);
    setCurrentUser(null);
  };

  // Effect to decode the token and fetch current user information
  useEffect(() => {
    const getCurrentUser = async () => {
      if (token) {
        const { username } = jwt_decode(token);
        JoblyApi.token = token;
        const user = await JoblyApi.getCurrentUser(username);
        setCurrentUser(user);
      }
    };
    getCurrentUser();
  }, [token]);

  // Protect routes by redirecting non-logged-in users to login
  function PrivateRoute({ children, ...rest }) {
    return (
      <Route
        {...rest}
        render={({ location }) =>
          currentUser ? (
            children
          ) : (
            <Redirect to={{
              pathname: "/login",
              state: { from: location }
            }} />
          )
        }
      />
    );
  }

  return (
    <UserContext.Provider value={{ currentUser, login, signup, logout }}>
      <BrowserRouter>
        <div className="App">
          <nav>
            <a href="/">Home</a> | 
            <a href="/companies">Companies</a> | 
            <a href="/jobs">Jobs</a> | 
            {currentUser ? (
              <>
                <span>Welcome, {currentUser.username}!</span> | 
                <button onClick={logout}>Logout</button> | 
                <a href="/profile">Profile</a>
              </>
            ) : (
              <>
                <a href="/login">Login</a> | 
                <a href="/signup">Signup</a>
              </>
            )}
          </nav>
          <Switch>
            <Route exact path="/" component={HomePage} />
            <PrivateRoute exact path="/companies">
              <CompanyList />
            </PrivateRoute>
            <PrivateRoute exact path="/companies/:handle">
              <CompanyDetail />
            </PrivateRoute>
            <PrivateRoute exact path="/jobs">
              <JobList />
            </PrivateRoute>
            <PrivateRoute exact path="/profile">
              <Profile />
            </PrivateRoute>
            <Route exact path="/login" component={Login} />
            <Route exact path="/signup" component={Signup} />
          </Switch>
        </div>
      </BrowserRouter>
    </UserContext.Provider>
  );
}

export default App;
