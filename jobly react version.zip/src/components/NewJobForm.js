
import React, { useState } from 'react';

function NewJobForm({ addJob }) {
  const [formData, setFormData] = useState({ title: '', company: '', description: '' });

  const handleChange = (evt) => {
    const { name, value } = evt.target;
    setFormData(fData => ({ ...fData, [name]: value }));
  };

  const handleSubmit = (evt) => {
    evt.preventDefault();
    addJob(formData);
    setFormData({ title: '', company: '', description: '' });
  };

  return (
    <form onSubmit={handleSubmit}>
      <label htmlFor="title">Job Title:</label>
      <input
        type="text"
        id="title"
        name="title"
        value={formData.title}
        onChange={handleChange}
      />
      <label htmlFor="company">Company:</label>
      <input
        type="text"
        id="company"
        name="company"
        value={formData.company}
        onChange={handleChange}
      />
      <label htmlFor="description">Description:</label>
      <textarea
        id="description"
        name="description"
        value={formData.description}
        onChange={handleChange}
      />
      <button type="submit">Add Job</button>
    </form>
  );
}

export default NewJobForm;
