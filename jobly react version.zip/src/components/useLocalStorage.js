
import { useState } from 'react';

/** Custom hook for keeping state data synced with localStorage. */
function useLocalStorage(key, firstValue = null) {
  const initialValue = localStorage.getItem(key) || firstValue;

  const [item, setItem] = useState(initialValue);

  const setValue = (value) => {
    setItem(value);
    localStorage.setItem(key, value);
  };

  const removeValue = () => {
    setItem(null);
    localStorage.removeItem(key);
  };

  return [item, setValue, removeValue];
}

export default useLocalStorage;
