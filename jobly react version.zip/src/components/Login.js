
import React from 'react';

function Login() {
  return <h1>Login/Signup Page</h1>;
}

export default Login;
