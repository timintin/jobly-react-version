
import React from 'react';

function CompanyList() {
  return <h1>List of Companies</h1>;
}

export default CompanyList;
