
import React from 'react';

function JobList() {
  return <h1>List of Jobs</h1>;
}

export default JobList;
