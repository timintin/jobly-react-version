
import React from 'react';

function Signup() {
  return <h1>Signup Page</h1>;
}

export default Signup;
