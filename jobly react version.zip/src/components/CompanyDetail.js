
import React from 'react';

function CompanyDetail() {
  return <h1>Company Detail Page</h1>;
}

export default CompanyDetail;
