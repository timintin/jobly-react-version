
import React from 'react';

function HomePage() {
  return <h1>Welcome to Jobly!</h1>;
}

export default HomePage;
