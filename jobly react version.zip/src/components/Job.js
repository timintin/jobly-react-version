
import React from 'react';

function Job({ title, company, description }) {
  return (
    <div className="Job">
      <h3>{title}</h3>
      <p><strong>Company:</strong> {company}</p>
      <p><strong>Description:</strong> {description}</p>
    </div>
  );
}

export default Job;
